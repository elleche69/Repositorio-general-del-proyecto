
package ModelosTablas;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


/**
 * 
 * @author 1GBD09
 */


public class ModeloLineas extends AbstractTableModel{
    
    
    private final String[] columnNames = {"Id", "Hora salida", "Hora llegada", "Numero de albaran"};
   
    private Object[][] data;
         
        
    
    
    
    
    public int getColumnCount(){
        return columnNames.length;
    }
    
    public int getRowCount() {
        return data.length;
    }
    
    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
        return data[row][col];
    }
        

    public boolean isCellEditable(int row, int col) {
        
        boolean b = false;
        
        if(col == 12){b =true;}
            
        return true;
    }    
        
    
    
    public void setValueAt(Object value, int row, int col) {
        data[row][col] = value;
        fireTableCellUpdated(row, col);
    }    
    
    
   public void ResizeNumFilas(int size){
    
        data = new Object[size][4];
        
    }    
    
    
    
    
    
        
    
    
    
    
    
    
    
    
    
    
}
