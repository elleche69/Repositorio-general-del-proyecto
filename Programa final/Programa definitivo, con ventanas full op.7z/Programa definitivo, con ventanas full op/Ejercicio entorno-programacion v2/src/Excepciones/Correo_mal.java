




package Excepciones;





public class Correo_mal extends Exception{

    public Correo_mal() {
    }
    
    
    
    
    
    
}
