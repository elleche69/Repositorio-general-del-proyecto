
package Clases;

import java.util.Date;



public  class Trabajadores {
    
    private String dni;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String calle;
    private String portal;
    private int piso;
    private String mano;    
    private String telefono1;
    private String telefono2;
    private float salario;
    private String fecha_nac;
    private Centros centro;


    public Trabajadores(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, float salario, String fecha_nac,  Centros centro) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.calle = calle;
        this.portal = portal;
        this.piso = piso;
        this.mano = mano;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.salario = salario;
        this.fecha_nac = fecha_nac;
        
        this.centro = centro;
    }

    public Trabajadores(String dni, String nombre, String apellido1, String apellido2) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
    }

    public Trabajadores(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, float salario, String fecha_nac, String tipo) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.calle = calle;
        this.portal = portal;
        this.piso = piso;
        this.mano = mano;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.salario = salario;
        this.fecha_nac = fecha_nac;
        
    }

 
    
    
    
    public Trabajadores(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, float salario, String fecha_nac) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.calle = calle;
        this.portal = portal;
        this.piso = piso;
        this.mano = mano;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.salario = salario;
        this.fecha_nac = fecha_nac;
       
    }

    public Trabajadores(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, float salario, String fecha_nac, Centros centro, String tipo) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.calle = calle;
        this.portal = portal;
        this.piso = piso;
        this.mano = mano;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.salario = salario;
        this.fecha_nac = fecha_nac;
        this.centro = centro;
    
    }

    
    
    
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getPortal() {
        return portal;
    }

    public void setPortal(String portal) {
        this.portal = portal;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getMano() {
        return mano;
    }

    public void setMano(String mano) {
        this.mano = mano;
    }

    public String getTelefono1() {
        return telefono1;
    }

    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }

    public String getTelefono2() {
        return telefono2;
    }

    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(String fecha_nac) {
        this.fecha_nac = fecha_nac;
    }
    

    public Centros getCentro() {
        return centro;
    }

    public void setCentro(Centros centro) {
        this.centro = centro;
    }

 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
