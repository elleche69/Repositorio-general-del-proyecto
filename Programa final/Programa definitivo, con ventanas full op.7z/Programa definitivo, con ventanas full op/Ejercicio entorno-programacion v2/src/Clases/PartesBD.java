
package Clases;

import static Clases.GenericBD.GenerarConexion;
import static Clases.GenericBD.cerrarConexion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.MonthDay;
import java.time.Year;
import java.util.ArrayList;
import java.util.Date;

import org.w3c.dom.Document;



public class PartesBD {
    
   private static ArrayList<Partes> partes;
           
    public static ArrayList<Partes> BuscarPartesDelTrabajador(String dni){
    
               
        try{
            partes  = new ArrayList();
            Partes parte;
            GenerarConexion();
            String lista = "Select * from partestrabajobd where Dni_Logis = ? and Estado_Parte = ? order by num_parte"; 
            PreparedStatement ps = GenericBD.getCon().prepareStatement(lista); 
            ps.setString(1, dni);
            ps.setString(2, "Abierto");
            ResultSet resultado = ps.executeQuery();
            System.out.print("E");
            while (resultado.next()){
            
                parte = new Partes(resultado.getInt(1), resultado.getInt(2), resultado.getInt(3), resultado.getInt(4), resultado.getInt(5), resultado.getInt(6), resultado.getInt(7), resultado.getDate(11).toString(), resultado.getString(12), resultado.getString(8));
                System.out.print(parte.getId());
                partes.add(parte);
            }
        }    
        catch(Exception e){System.out.print("A");}
        cerrarConexion();
        return partes;
    }   
        
        
    public static boolean ComprobarFechaSiEstaDuplicado(String fecha){
        
        boolean b = false;
        try{
            
            GenerarConexion();        
            String busqueda = "Select * from partestrabajobd where fecha_parte = ?";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(busqueda);
            preparado.setString(1, fecha);
          
            ResultSet resultado = preparado.executeQuery();               
            if(resultado.next()){b = true;} 
            else{b = false;}
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "Q");}    
        cerrarConexion();    
        return b;     
    }         
     
    
    
    public static int GenerarId(){
    
        int id = 1;
        
        try{
            GenerarConexion(); 
            String busqueda = "select max(num_parte) from partestrabajobd";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(busqueda);
            ResultSet resultado = preparado.executeQuery(); 
            if(resultado.next()){
                id = resultado.getInt(1);
            }
            
        }
        catch(Exception e){}
        cerrarConexion();
        return id;
    }
            
    public static void GenerarParteNuevo(Partes parte){
    
        try{
          
            GenerarConexion();
            String insertar = "Insert into Partestrabajobd(NUM_PARTE, DNI_LOGIS, FECHA_PARTE, ESTADO_PARTE) Values(?,?,?,?)";
            
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(insertar);
            preparado_industrial.setInt(1, parte.getId());
            preparado_industrial.setString(2, parte.getTrabajador_logis().getDni());
            preparado_industrial.setString(3, parte.getFecha());
            preparado_industrial.setString(4, parte.getEstado());
            preparado_industrial.executeUpdate();
        
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "L");} 
        cerrarConexion();
    
    
        
    
    }        
        
        
    public static void UpdateElParte(Partes parte){
        
        
        
        try{
        
            GenerarConexion();
            String update = "Update partestrabajobd set KM_INICIO = ?, KM_FINAL = ?, GASTOS_GASOIL = ?, GASTOS_PEAJES = ?, GASTOS_DIETAS = ?, OTROS_GASTOS = ?, INCIDENCIAS = ? where num_parte = ?";
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(update);
            preparado_industrial.setInt(1, parte.getKm_inicio());
            preparado_industrial.setInt(2, parte.getKm_final());
            preparado_industrial.setInt(3, parte.getGastos_gasoil());
            preparado_industrial.setInt(4, parte.getGastos_peaje());
            preparado_industrial.setInt(5, parte.getGastos_dietas());
            preparado_industrial.setInt(6, parte.getOtros_gastos());
            preparado_industrial.setString(7, parte.getIncidencias());
            preparado_industrial.setInt(8, parte.getId());
            preparado_industrial.executeUpdate();
            
            
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "P");}
        cerrarConexion();
    }
    
    
    public static void CerrarPorTerceraVez(Partes parte){
    
        try{
            GenerarConexion();
            String update = "Update partestrabajobd set KM_INICIO = ?, KM_FINAL = ?, GASTOS_GASOIL = ?, GASTOS_PEAJES = ?, GASTOS_DIETAS = ?, OTROS_GASTOS = ?, ESTADO_PARTE = ?, MATRICULA = ? where num_parte = ?";
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(update);
            preparado_industrial.setInt(1, parte.getKm_inicio());
            preparado_industrial.setInt(2, parte.getKm_final());
            preparado_industrial.setInt(3, parte.getGastos_gasoil());
            preparado_industrial.setInt(4, parte.getGastos_peaje());
            preparado_industrial.setInt(5, parte.getGastos_dietas());
            preparado_industrial.setInt(6, parte.getOtros_gastos());
            preparado_industrial.setString(7, "Cerrado");
            preparado_industrial.setString(8, parte.getVehiculo().getMatricula());
            preparado_industrial.setInt(9, parte.getId());
            preparado_industrial.executeUpdate();
        
        
        
        
        
        }
        catch(Exception e){}
        cerrarConexion();
        
    
    
    
    
    
    
    
    }
    
    
        
    
    public static ArrayList<Partes> FiltrarPartesPorFecha(String fecha_primera, String fecha_segunda){
    
        ArrayList<Partes> lista_partes = new ArrayList();
        Vehiculo t;
        try{
            GenericBD.GenerarConexion();
            String select = "Select * from partestrabajobd where fecha_parte >= ? and fecha_parte <= ? order by fecha_parte";
            System.out.print("t1");
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(select);
            preparado.setString(1, fecha_primera);
            preparado.setString(2, fecha_segunda);
            ResultSet resultado = preparado.executeQuery();
            int n = 0;
            System.out.print("t1");
            while(resultado.next()){
                if (n < 15){                    
                    Partes parte = new Partes(resultado.getInt(1), resultado.getInt(2), resultado.getInt(3), resultado.getInt(4), resultado.getInt(5), resultado.getInt(6), resultado.getInt(7), resultado.getDate(11).toString(), resultado.getString(12), resultado.getString(8), TrabajadoresBD.LograrTrabajadorPorDni(resultado.getString(10)), new Vehiculo(resultado.getString(13)));
                    lista_partes.add(parte);
                    
                }
                n = n + 1;
            }
            
            ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.PasarNumResultados(n);
            System.out.print("t1");
        }
        catch(Exception e){}
        GenericBD.cerrarConexion();
    
        return lista_partes;
    }
    
        
    
        
   public static void UpdatePorElAdmin(Partes p){
   
       GenericBD.GenerarConexion();
       String update = "Update partestrabajobd set km_inicio = ?, km_final = ?, gastos_gasoil = ?, gastos_peajes = ?, gastos_dietas = ?, otros_gastos = ?, matricula = ?, dni_admin = ? where num_parte = ?";
       try{
       
           PreparedStatement pp = GenericBD.getCon().prepareStatement(update);
           System.out.print("tY");
           pp.setInt(1, p.getKm_inicio());
           pp.setInt(2, p.getKm_final());
           pp.setInt(3, p.getGastos_gasoil());
           pp.setInt(4, p.getGastos_peaje());
           pp.setInt(5, p.getGastos_dietas());
           pp.setInt(6, p.getOtros_gastos());
           pp.setString(7, p.getVehiculo().getMatricula());
           pp.setString(8, p.getTrabajador_admin().getDni());
           pp.setInt(9, p.getId());       
           pp.executeUpdate();
          
           
        } 
       catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}   
       GenericBD.cerrarConexion();
       
    }   
       
       
       
    public static void BorrarParte(int id){
    
        GenericBD.GenerarConexion();
        String delete = "Delete from partestrabajobd where num_parte = ?";
        try{
       
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(delete);
            preparado.setInt(1, id);
            preparado.executeUpdate();
                               
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}
    
    
    }
    
    
    
    
    
    public static void RecuperarXML(){
    
    
        GenericBD.GenerarConexion();
        String delete = "select * from RepositorioBDPartesXML where id_entrada = ?";
        try{
    
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(delete);
            preparado.setInt(1, 1);
            ResultSet r = preparado.executeQuery();
            if(r.next()){
               System.out.print(r.getClob(4).length());
            }
            
             
            }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}
    }
    
    
    
    
    public static ArrayList<Partes> FiltrarPartesPorFechaBD(String fecha){
    
        ArrayList<Partes> lista_partes = new ArrayList();
        Vehiculo t;
        try{
            GenericBD.GenerarConexion();
            String select = "Select * from partestrabajobd where fecha_parte like ?";
            System.out.print("t1");
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(select);
            preparado.setString(1, "%"+fecha+"%");           
            ResultSet resultado = preparado.executeQuery();
          
            System.out.print("t1");
            while(resultado.next()){
                                   
                    Partes parte = new Partes(resultado.getInt(1), resultado.getInt(2), resultado.getInt(3), resultado.getInt(4), resultado.getInt(5), resultado.getInt(6), resultado.getInt(7), resultado.getDate(11).toString(), resultado.getString(12), resultado.getString(8), TrabajadoresBD.LograrTrabajadorPorDni(resultado.getString(10)), TrabajadoresBD.LograrTrabajadorPorDni(resultado.getString(9)), new Vehiculo(resultado.getString(13)));
                    lista_partes.add(parte);                                    
               
            }
            
            
            System.out.print("t1");
        }
        catch(Exception e){}
        GenericBD.cerrarConexion();
    
        return lista_partes;
    }   
       
       
    public static int RecuperarIdMax(){
    
        int id = 0;
        GenericBD.GenerarConexion();
        String estamento = "select max(id_informe) from InformesXMLTYPE";
        try{
        
            PreparedStatement sta = GenericBD.getCon().prepareStatement(estamento);
            ResultSet y = sta.executeQuery();
            if (y.next()){
                id = y.getInt(1) + 1;
            }
        
        
        }
        catch(Exception e){}
        
        
    
        return id;
    }   
       
       
   
      
   
   
    public static void InsertarInformesXML(String documento){
    
        GenericBD.GenerarConexion();
        String insertar = "Insert into InformesXMLTYPE VALUES(?, XMLType(?),?)";
        
        try{
            PreparedStatement ps = GenericBD.getCon().prepareStatement(insertar);
            ps.setInt(1, RecuperarIdMax());
            ps.setString(2, documento);
            ps.setString(3, (MonthDay.now().getMonthValue()-1) + "/" +Year.now().toString().substring(2));
            ps.executeUpdate();
        
        }
        catch(Exception e){}
        
        GenericBD.cerrarConexion();
        
    }
    
    
    public static ArrayList<String> RecuperarFechasInformesXML(){
    
        ArrayList<String> fechas = new ArrayList();
        GenericBD.GenerarConexion();
        String query = "Select Mes_Año from InformesXMLTYPE";
        
        try{
        
            PreparedStatement pps = GenericBD.getCon().prepareStatement(query);
            ResultSet resultado = pps.executeQuery();
            
            while(resultado.next()){
            
                fechas.add(resultado.getString(1));
            
            }
        
        
        
        
        }
        catch(Exception e){}
        
        return fechas;
    }
   
   
   
    
    
    
    
    
}
