


package Clases;




public class LineaPartes {
    
    private int id;
    
    private String hora_salida;
    
    private String hora_llegada;
        
    private Albaran albaran;
    
    private Partes parte;

    public LineaPartes(int id, String hora_salida, String hora_llegada, Albaran albaran, Partes parte) {
        this.id = id;
        this.hora_salida = hora_salida;
        this.hora_llegada = hora_llegada;       
        this.albaran = albaran;
        this.parte = parte;
    }

    public LineaPartes(int id, String hora_salida, String hora_llegada, Albaran albaran) {
        this.id = id;
        this.hora_salida = hora_salida;
        this.hora_llegada = hora_llegada;
        this.albaran = albaran;
    }

    public LineaPartes(String hora_salida, String hora_llegada, Albaran albaran) {
        this.hora_salida = hora_salida;
        this.hora_llegada = hora_llegada;
        this.albaran = albaran;
    }

    public LineaPartes(int id, Partes parte) {
        this.id = id;
        this.parte = parte;
    }

    
    
    
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHora_salida() {
        return hora_salida;
    }

    public void setHora_salida(String hora_salida) {
        this.hora_salida = hora_salida;
    }

    public String getHora_llegada() {
        return hora_llegada;
    }

    public void setHora_llegada(String hora_llegada) {
        this.hora_llegada = hora_llegada;
    }

  
    public Albaran getAlbaran() {
        return albaran;
    }

    public void setAlbaran(Albaran albaran) {
        this.albaran = albaran;
    }

    public Partes getParte() {
        return parte;
    }

    public void setParte(Partes parte) {
        this.parte = parte;
    }
    
    
    
    
    
    
    
    
    
}
