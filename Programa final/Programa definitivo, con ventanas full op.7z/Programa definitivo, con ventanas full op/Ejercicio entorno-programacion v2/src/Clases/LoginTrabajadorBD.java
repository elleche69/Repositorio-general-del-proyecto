
package Clases;

import static Clases.GenericBD.GenerarConexion;
import static Clases.GenericBD.cerrarConexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;




public class LoginTrabajadorBD {
    
    public static String BuscarLoginSiEsCorrecto(String user, String contraseña){
    
        String dni = null;
        
        try{
            GenerarConexion();
            String lista = "Select DniTrabajador from LoginTrabajadores where usuario = ? and contraseña = ?";
            PreparedStatement ps = GenericBD.getCon().prepareStatement(lista);
            ps.setString(1, user);
            ps.setString(2, contraseña);
            ResultSet result = ps.executeQuery();
            if (result.next()){dni = result.getString(1);}
            else {dni = "a";}
        
        
        
        }
        catch(Exception e){}
        
        
        
    
        return dni;
    }
    
    
    
    
    
    
    
    
}
