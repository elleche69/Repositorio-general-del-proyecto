/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author 1GBD09
 */
public class VentanaFondo extends javax.swing.JFrame {

    /**
     * Creates new form Ventana_fondo
     */
    public VentanaFondo() {
        initComponents();
    }

   
    
    public void AñadirComponentes(){    
       AñadirPanel();
       AñadirPanel2();
       AñadirPanel3();
       PonerICono();
       
    }    
    
    public void AñadirPanel(){
        panel = new JPanel();
        this.add(panel).setBounds(0, 0, 1920, 340);        
        panel.setBackground(Color.GRAY);
        AñadirLabelAlPanel();
    }
    
    
    public void AñadirLabelAlPanel(){
        label = new JLabel();
        panel.add(label);
        label.setBounds(480, 75, 960, 150);
        label.setIcon((new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/letras_inicio.png"))));      
    }     
        
       
            
    
    public void AñadirPanel2(){
    
        panel2 = new JPanel();
        this.add(panel2).setBounds(0, 340, 1920, 340); 
        float[] hsb = new float[3];
        Color.RGBtoHSB(255, 204, 102, hsb);
        panel2.setBackground(Color.getHSBColor(hsb[0], hsb[1], hsb[2]));
        panel2.setLayout(new BorderLayout());
        AñadirImagenesEnPanelDos("/Ventanas/Imagenes/la_bala_inicio_dcha.png");
        AñadirSegundaImagen("/Ventanas/Imagenes/la_bala_inicio_izda.png");
    
    }
    
    
    public void AñadirImagenesEnPanelDos(String ruta){
    
        label2 = new JLabel();        
        panel2.add(label2, BorderLayout.EAST);        
        label2.setIcon(new javax.swing.ImageIcon(getClass().getResource(ruta)));
    }    
        
    
    public void AñadirSegundaImagen(String ruta){
        label3 = new JLabel();        
        panel2.add(label3, BorderLayout.WEST);        
        label3.setIcon(new javax.swing.ImageIcon(getClass().getResource(ruta)));
    }
    
    
    
    
        
    
    
    
    
    public void AñadirPanel3(){    
        panel3 = new JPanel();
        this.add(panel3).setBounds(0, 680, 1920, 340); 
        panel3.setBackground(Color.GRAY);
        
    }    
    
      public void PonerICono(){   
       ImageIcon ImageIcon = new ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_big.gif"));
       Image Image = ImageIcon.getImage();
       this.setIconImage(Image);
    }   
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Transportes La Bala S.Coop.");
        setPreferredSize(new java.awt.Dimension(1920, 1080));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 408, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 347, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaFondo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaFondo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaFondo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaFondo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaFondo().setVisible(true);
            }
        });
    }
    
    
    
    
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JLabel label;
    private JLabel label2;
    private JLabel label3;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
