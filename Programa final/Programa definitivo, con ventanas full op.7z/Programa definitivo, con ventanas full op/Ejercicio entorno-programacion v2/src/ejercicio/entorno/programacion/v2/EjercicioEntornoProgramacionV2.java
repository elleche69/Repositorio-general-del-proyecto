




package ejercicio.entorno.programacion.v2;

import Ventanas.*;
import Clases.*;
import Excepciones.*;
import java.util.ArrayList;
import java.util.Date;
import Metodos.MetodosComprobarInsultos;
import Metodos.MetodosComprobarDatosDeLasLineas;
import javax.swing.Icon;
import Parser.Parseador;

import java.time.Instant;
/**
 * 
 * @author 1GBD09
 */

public class EjercicioEntornoProgramacionV2 {
    private static LoginTrabajador login;
    private static VentanaLineas ventana_lineas;
    private static VentanaPartes ventana_partes;
    private static VentanaInicio ventana_inicio;
    private static MenuCentros menu_centros;
    private static MenuTrabajadores menu_trabajadores;
    private static CRUDCentros crud_centros;
    private static CRUDTrabajadores crud_trabajadores;
    private static ArrayList<Centros> centros; 
    private static ArrayList<Partes> partes;
    private static int centro_index_seleccionado; 
    private static Trabajadores trabajador; 
    private static Centros centro; 
    private static int opcion; 
    private static VisualizarTrabPorCentros visualizar;
    private static Login log;
    private static String dnit;
    private static String tipo = null;
    private static TrabajadoresLogistica logistica = null;
    private static TrabajadoresAdministracion administracion = null;
    private static Partes t_parto;
    private static VentanaAdministrarPartes ventana_administrar_partes;
    private static int indicador_de_linea;
    private static CrudPartesYLineasAdmin crud_partes_y_lineas_admin;
    private static Parseador parser;
    private static VentanaFondo ventana_fondo;
    
    
    public static void main(String[] args) {
        //ventana_lineas = new VentanaLineas();
        //ventana_lineas.setVisible(true);
        ventana_fondo = new VentanaFondo();
        ventana_fondo.setVisible(true);
        ventana_fondo.AñadirComponentes();
        //GenerarVentanaDeAdministrarPartes();
        
        log = new Login(null, true);
        log.setVisible(true);
        log.setLocationRelativeTo(null);
        
        
        
    }
    
              
//METODOS GENERAR VENTANAS    
    
    /**
     * Metodo que junta todo los metodos de generacion de ventanas
     * @param b es el indicador que indica si aparte de abrir una ventana n tiene que cerrar alguna otra
     * @param n es el indicador que indica que ventana abrir
     */
    public static void EleccionGenerarVentanas(int b, int n){
    
        switch (n){
        
            case 1:               
                GenerarVentanaPrincipal(b);
                break;                       
            case 2:
                GenerarMenuCentros(b);
                break;                            
            case 3:                             
                GenerarMenuTrabajadores(b);  
                break;            
            case 4:  
                GenerarCrudCentros();
                break;                
            case 5: 
                GenerarCrudTrabajadores();
                break;
            case 6: 
                GenerarTabla();
                break;
            case 7:
                GenerarVentanaParte(b);
                break;
            case 8:                
                GenerarVentanaLineasParte();
                break;
            case 9: 
                GenerarVentanaDeAdministrarPartes(b);
                break;
            case 10:
                GenerarUltimaVentana();
                break;
                
        }        
    }            
               
    /**
     * Metodo que genera la ventana principal
     * @param b cierra una ventana anterior segun su valor
     */            
    public static void GenerarVentanaPrincipal(int b){          
        switch (b){
            case 1:
                menu_centros.dispose();
                break;
            case 2: 
                menu_trabajadores.dispose();
                break;
            case 3:
                ventana_administrar_partes.dispose();
                break;
        }            
        ventana_inicio = new VentanaInicio();
        ventana_inicio.setVisible(true);
        ventana_inicio.setLocationRelativeTo(null);
    }     
        
        
    /**
     * Metodo que genera la ventana de eleccion del centro al cual quieres hacerle algun cambio
     * @param b indica que cerrar anteriormente
     */   
    
    public static void GenerarMenuCentros(int b){    
        if(b == 1){
            crud_centros.dispose();}
        else{
            if(b ==2){visualizar.dispose();}
            else{ ventana_inicio.dispose();}
        }  
                        
        menu_centros = new MenuCentros();
        menu_centros.setVisible(true);
        menu_centros.setLocationRelativeTo(null);
    }    
    
    /**
     * Metodo que genera la ventana menu para modificar los trabajadores
     * @param b indica que cerrar (si se ha de cerrar algo)
     */
        
    public static void GenerarMenuTrabajadores(int b){    
        if (b == 1){
            crud_trabajadores.dispose();}        
        else{ventana_inicio.dispose();}                
        menu_trabajadores = new MenuTrabajadores();
        menu_trabajadores.setVisible(true);
        menu_trabajadores.setLocationRelativeTo(null);
    
    }
    
    /**
     * Metodo que genera la ventana en la cual AHORA SI se hacen los cambios de los centros
     */
    
    public static void GenerarCrudCentros(){
        menu_centros.dispose();        
        crud_centros = new CRUDCentros();
        crud_centros.setVisible(true);
        crud_centros.setLocationRelativeTo(null);
    }
    
    
    /**
     * Metodo que genera la ventana en la cual AHORA SI se modificaran trabajadores al antojo del omnipotente admin
     */
    
    
    public static void GenerarCrudTrabajadores(){
        menu_trabajadores.dispose();
        crud_trabajadores = new CRUDTrabajadores();
        crud_trabajadores.setVisible(true);
        crud_trabajadores.setLocationRelativeTo(null);
    }
    
    
    /**
     * Metodo que genera la ventana en la cual se visualizan todos los trabajadores de un centro x
     */
    
    
    public static void GenerarTabla(){    
        menu_centros.dispose();
        visualizar = new VisualizarTrabPorCentros();
        visualizar.setVisible(true);
        visualizar.setLocationRelativeTo(null);
    }
    
    
    /**
     * Metodo que genera la ventana en la cual los trabajadores de logistican crean, editan o cierran sus partes 
     * @param b indica si cerrar algo antes o no
     */
    
    public static void GenerarVentanaParte(int b){        
        if (b == 1){ventana_lineas.dispose();}
        ventana_partes = new VentanaPartes();
        ventana_partes.setVisible(true); 
        ventana_partes.setLocationRelativeTo(null);
        AñadirDatosPartes();                   
    }
    
    
    /**
     * Metodo que genera la ventana de añadir lineas
     */
    
    public static void GenerarVentanaLineasParte(){
        ventana_partes.dispose();
        ventana_lineas = new VentanaLineas();
        ventana_lineas.setVisible(true);
        ventana_lineas.setLocationRelativeTo(null);
    }    
    
    /**
     * Metodo que genera la ventana donde los admins hacen lo que les da la gana con los partes
     * @param b lo de siempre
     */
    
    
    public static void GenerarVentanaDeAdministrarPartes(int b){
        if(b == 1){crud_partes_y_lineas_admin.dispose();}
        ventana_inicio.dispose();
        ventana_administrar_partes = new VentanaAdministrarPartes();
        ventana_administrar_partes.setVisible(true);
        ventana_administrar_partes.setLocationRelativeTo(null);
    }
    
    
    /**
     *  Metodo que genera la ultima ventana, en la que los admins admiten, liquidan o editan partes
     */
    
    public static void GenerarUltimaVentana(){
    
        ventana_administrar_partes.dispose();
        crud_partes_y_lineas_admin = new CrudPartesYLineasAdmin();
        crud_partes_y_lineas_admin.setVisible(true);
        crud_partes_y_lineas_admin.setLocationRelativeTo(null);
    
    }
    
    
    
    
//FINAL METODOS GENERAR VENTANAS    
    
    
//METODOS RELATIVOS A MENUS    
    
    /**
     * Metodo que manda los centros 
     * @param g 
     */
    public static void ConseguirIdsDeLaBase(int g){                      
        centros = CentrosBD.Introducir_datos_en_combo();
        
        if(g == 1){ menu_trabajadores.RecuperarDatosIds(centros);}
        else{menu_centros.RecuperarDatosDeLaBase(centros);} 
    }        
            
                        
    /**
     * Setter del id del centro seleccionado
     * @param id el id del centro
     */
    public static void ConseguirCentroSeleccionado(int id){
    
        centro_index_seleccionado = id;        
    }
    
    /**
     * Setter de la opcion
     * @param n indice de la opcion
     */
    public static void ConseguirOpcion(int n){  
        opcion = n;
        crud_trabajadores.PasarIndexOpcion(n);    
    }
    
    
//FIN DE LOS METODOS DE ESTE TIPO   
    
    
  
//LLAMADA A METODOS "CRUD" TRABAJADORES
       
    /**
     * Metodo que recibe un ArrayList de String usados para crear un objeto de 
     * tipo trabajador, y lo envia para updatear a la base
     * @param data los datos de la modificacion
     * @param tipo_modif el tipo del trabajador(admin o logis)
     */
    public static void Modificar(ArrayList<String> data, String tipo_modif){
    
        int cx = 0;        
        while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;        
        }        
        centro = centros.get(cx);        
        trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Float.parseFloat(data.get(10)),data.get(11), centro); 
        System.out.print(tipo_modif);
        Clases.TrabajadoresBD.Modificar_datos(trabajador, tipo_modif);    
    }  
           
    /**
     * Metodo que crea un objeto tipo trabajador a partir de los datos insertados
     * @param data datos del trabajador
     * @param tipe tipo
     */
    public static void Añadir(ArrayList<String> data, String tipe){
    
        if(Clases.TrabajadoresBD.Comprobar(data.get(0)) == true){
           
            int cx = 0;        
            while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;}  
            centro = centros.get(cx);   
            trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Float.parseFloat(data.get(10)),data.get(11), centro);        
            
            Clases.TrabajadoresBD.Añadir_Nuevo(trabajador, tipe);           
       }
    }
        
    /**
     * Borra el trabajador a partir del dni
     * @param dna 
     */       
    public static void Borrar(String dna){
    
        Clases.TrabajadoresBD.Borrar_Datos(dna);
   } 
    
//FIN DE METODOS CRUD TRABAJADORES    
    
    
    /**
     * Metodo que valida que el dni introducido en la ventana de modificar 
     * @param dna dato introducido en el campo del dni
     */
    
   public static void Validar_Dato_Introducido(String dna){
   
       Trabajadores ttrabajador = TrabajadoresBD.Validar_Trabajadores(dna, centro_index_seleccionado);
   
         if(ttrabajador != null && opcion == 1){
           
           crud_trabajadores.Habilitar_campos(true);
           crud_trabajadores.Enseñar_Datos(ttrabajador, tipo);
           crud_trabajadores.getTimer().stop();
        }   
           
        else{
       
           if(trabajador != null && opcion != 1){
           
               crud_trabajadores.Habilitar_campos(false);
               crud_trabajadores.Enseñar_Datos(ttrabajador, tipo);
               crud_trabajadores.getTimer().stop();
           }    
               
           else{           
               javax.swing.JOptionPane.showMessageDialog(null, "Trabajador no encontrado");
            }
        }      
   
   
   
   }
    /**
     * Setter del tipo del trabajador actual
     * @param tipoTrabajador tipo
     */
    public static void RecogerTipo(String tipoTrabajador){
    
        tipo = tipoTrabajador;
    }    
    
    
    
                     
    
//METODOS RELATIVOS A LOS CENTROS
   
    /**
     * Recoje el index de la opcion escogida
     * @param h 
     */
   public static void RecojerOpcionEscogida(int h){      
       opcion = h;
       if (opcion != 1 && opcion != 4){
           crud_centros.RecogerCentro(centros.get(menu_centros.PasarIndex() - 1), opcion);}
       else{
       
           if(opcion != 4){crud_centros.RecogerCentro(null, opcion);}
           
           else{visualizar.EnseñarDatos(CentrosBD.VisualizarTrabajadoresCentro(menu_centros.PasarIndex()));}
        }       
    }           
    /**
     * Manda los tipos a la ventana
     * @param todo_tipo 
     */
    public static void RecogerTipo(ArrayList<String> todo_tipo){
   
       visualizar.EnseñarTipo(todo_tipo);
        
   }
       
    /**
     * No confirmamos que funcione 
     * @param id
     * @param trab 
     */
    public static void CargaADemanda(int id, ArrayList<Trabajadores> trab){
    
       int n = 0;
        
        while (n < centros.size() && centros.get(n).getId() != id){
        
            n = n + 1;
        }         
        centros.get(n).setTrabajadores(trab);
    }   
    
    
       
       
    /**
     * Comprueba que no este el id repetido
     * @param id_nuevo
     * @return 
     */        
        
           
    public static boolean ComprobarIdCentroNuevo(int id_nuevo){
    
        boolean b = false;
    
        int n = 0;
        
        while(n < centros.size()){        
            if (id_nuevo == centros.get(n).getId()){
                n = centros.size();
                b = true;}
            else{n = n + 1;}
        }       
        return b;    
    }      
    
    /**
     * Activa la modificacion, eliminacion y la insercion
     * @param eleccion la opcion elegida
     * @param data los datos necesarios para la opcion
     */
        
    public static void FinalizarAccion(int eleccion, ArrayList<String> data){
        if (eleccion != 3){
            Centros centrox = new Centros(Integer.parseInt(data.get(0)), data.get(1), data.get(2), Integer.parseInt(data.get(3)), data.get(4), data.get(5), data.get(6), data.get(7));
            if(eleccion == 1){
                CentrosBD.AñadirCentro(centrox);
            }
            else{CentrosBD.ModificarCentro(centrox);}        
        }
        else{
            int id_new = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Introduzca id del centro al cual se redijiran los trabajadores"));
            TrabajadoresBD.Cambiar_de_centro(Integer.parseInt(data.get(0)), id_new);
            CentrosBD.EliminarCentro(Integer.parseInt(data.get(0)));
        
        }
       
    
    }
    
                                                  
    //Metodos relativos al login
    
    
    /**
     * Setter de trabajador logistica y admin
     * @param t1
     * @param t2 
     */
    
    public static void LograrTipoLogin(TrabajadoresLogistica t1, TrabajadoresAdministracion t2){    
        administracion = t2;
        logistica = t1;
    }
    
    
    /**
     * Llama al metodo que busca en la bd si existe este usuario, para ello le pasa dos
     * parametros 
     * @param user usuario
     * @param contraseña password
     */
    public static void Entrada(String user, String contraseña){       
        BuscarDNILogin(Clases.LoginTrabajadorBD.BuscarLoginSiEsCorrecto(user, contraseña));
    }    
    
    
    
    /**
     * Segun si el admin o el logis esta lleno se accede a la ventana que le corresponde a cada rol
     * @param dni 
     */
    
    
    
    public static void BuscarDNILogin(String dni){
        dnit = dni;
        Clases.TrabajadoresBD.BuscarLogin(dnit);
    
        if (administracion == null && logistica != null){
            
            log.dispose();
            
            partes = Clases.PartesBD.BuscarPartesDelTrabajador(dnit);
            EleccionGenerarVentanas(0,7);
        }    
        else{   
           if(logistica == null && administracion != null){
                log.dispose();
               
                EleccionGenerarVentanas(0,1);
           }    
           else{log.MostrarAmenazaDeMuerte();}           
        }
    }    
           
           
    
    //Metodos relativos al las lineas y a los partes

               
    public static void CogerListaFerrari(){
    
        ventana_partes.LlenarForocoches(Clases.VehiculosBD.DevuelveLaLista());
    }
        
    /**
     * Llama al metodo que genera un parte nuevo
     * @param fecha 
     */
    
    public static void GenerarParte(String fecha){
        
        Partes parte;
        
        parte = new Partes(PartesBD.GenerarId() + 1, fecha, "Abierto", logistica);
        
        if (PartesBD.ComprobarFechaSiEstaDuplicado(fecha) == false){
            PartesBD.GenerarParteNuevo(parte);
            ventana_partes.AñadirParteNuevo(parte);
            
        }    
        else{javax.swing.JOptionPane.showMessageDialog(ventana_lineas, "Parte ya generado en la misma fecha");}
    }    
        
        
        
    public static void AñadirDatosPartes(){
        ventana_partes.LlenarComboYTabla(partes);
    }    
                
    /**
     * Llama al metodo que edita los datos del parte
     */
    public static void EditarPartes(){    
        
        ArrayList<Integer> data = ventana_partes.RecojerDatosDeLaTabla();
        
        if(MetodosComprobarInsultos.ComprobarArea(ventana_partes.getArea().getText()) == false){
            Partes parte = new Partes(data.get(6), data.get(0),  data.get(1),  data.get(2),  data.get(3),  data.get(4),  data.get(5),  ventana_partes.getArea().getText(), logistica);     
            PartesBD.UpdateElParte(parte);
        }
        else{
            ventana_partes.RestaurarIncidencia();
             javax.swing.JOptionPane.showMessageDialog(null, "Pues yo mecago en tus muertos mas recientes", "Cavron te vamos a matar", 2);
             ventana_partes.NoAceptamosInsultos("No se da ayuda a motherfuckers como tu");
        }   
    }    
        
    
    /**
     * Llama al metodo que añade lineas en la bd, (le pasa datos)
     * @param datas 
     */
    public static void AñadirLineasAlParte(ArrayList<Integer> datas){
    
        Partes parte = new Partes(datas.get(6), datas.get(0),  datas.get(1),  datas.get(2),  datas.get(3),  datas.get(4),  datas.get(5),  ventana_partes.getArea().getText(), logistica);
        t_parto = parte;        
        ventana_lineas.AñadirLineasQueYaEstan(Clases.LineasPartesBD.Buscar(parte));
    }    
                
                                
      /**
       * Mas para 
       * @param data
       * @param matricula 
       */         
    public static void CerrarPartes(ArrayList<Integer> data, String matricula){    
        Partes parte = new Partes(data.get(6), data.get(0),  data.get(1),  data.get(2),  data.get(3),  data.get(4),  data.get(5), null, logistica, VehiculosBD.ConseguirVehiculo(matricula));        
        PartesBD.CerrarPorTerceraVez(parte);
    }
    
    
    public static void Recuperar_Datos_Lineas(ArrayList<String> data, int df){
        indicador_de_linea = df;
        Metodos.MetodosComprobarDatosDeLasLineas.ElQueRecibeElArrayLost(data);
          
    }     
        
        
        
    public static void DecidirSiInsertarONo(boolean a, boolean b, ArrayList<String> datos_lineas){
    
        if(a == false && b == false){
            ventana_lineas.DesactivarLineas(indicador_de_linea);
            ventana_lineas.Añadir_nueva_linea();          
            LineasPartesBD.AñadirLineaNuevaEnBD(new LineaPartes(Clases.LineasPartesBD.GenerarId() + 1, datos_lineas.get(1) + ":" + datos_lineas.get(2), datos_lineas.get(3) + ":" + datos_lineas.get(4),  new Albaran(Integer.parseInt(datos_lineas.get(0))), t_parto));
        }
    }    
        
   
           
    
    //Comienzo de Metodos adminpartes
    
    /**
     * 
     * @param una
     * @param dos 
     */
    public static void BusquedaPorFecha(String una, String dos){
    
        ventana_administrar_partes.RecojerPartes(PartesBD.FiltrarPartesPorFecha(una, dos));
    }
    
    
    public static void PasarNumResultados(int nt){
        
        ventana_administrar_partes.RecuperarNumeroDeResultados(nt);
    }
            
        
    public static void PasarElParteElegidoParaEditar(Partes parte){    
        EleccionGenerarVentanas(0, 10);
        crud_partes_y_lineas_admin.RecibirTodosLosDatos(parte, LineasPartesBD.Buscar(parte));
        crud_partes_y_lineas_admin.AñadirDatosTabla1();
        crud_partes_y_lineas_admin.AñadirDatosTabla2();
    }
    
    
    
    public static void FinalizarEdicionPorParteDelAdministrador(ArrayList<String> p, ArrayList<String> lineas){
        
        Partes parte = new Partes(Integer.parseInt(p.get(7)), Integer.parseInt(p.get(0)), Integer.parseInt(p.get(1)), Integer.parseInt(p.get(2)), Integer.parseInt(p.get(3)), Integer.parseInt(p.get(4)), Integer.parseInt(p.get(5)), administracion, new Vehiculo(p.get(6)));
        ArrayList<LineaPartes> el_array_lineas = new ArrayList();        
        int j = 0;
        while (j < (lineas.size()-4)/4){
        
            el_array_lineas.add(new LineaPartes(Integer.parseInt(lineas.get(j+3)), lineas.get(j), lineas.get(j+1), new Albaran(Integer.parseInt(lineas.get(j+2)))));            
            j = j + 4;
        }
        
        PartesBD.UpdatePorElAdmin(parte);
        int n = 0;
        while(n < el_array_lineas.size()){
            LineasPartesBD.UpdatePorElAdmin(el_array_lineas.get(n));
            n = n + 1;
        }
        
        
    }    
        
    
    public static void EliminarParteYLinea(int id_de_parte){    
        LineasPartesBD.BorrarLineasDeEseParte(id_de_parte);
    }
    
    
    
    //Parser
    
    
    
    
    public static void CrearParser(String fechya){        
        Parseador p = new Parseador(fechya);
        p.Marcha();
       
    }
    
    
    
                    
    public static ArrayList<Partes> getPartes() {
        return partes;
    }

    public static void setPartes(ArrayList<Partes> partes) {
        EjercicioEntornoProgramacionV2.partes = partes;
    }
    
                
    
    public static void Actualizar(){    
        partes = Clases.PartesBD.BuscarPartesDelTrabajador(dnit);        
        ventana_partes.SetterPartes(partes);               
    }
       
    public static ArrayList<String> RetornaElArrayList(){        
        return PartesBD.RecuperarFechasInformesXML();    
    }
    
    
    public static String getDnit() {
        return dnit;
    }

    public static void setDnit(String dnit) {
        EjercicioEntornoProgramacionV2.dnit = dnit;
    }
    
    
    
} 

















    
            
    
    
    
    
      
    
   
   
   
   
   
    
    
    
    

